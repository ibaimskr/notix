package com.example.reto1_agendaonlinemusica.Network;

/**
 * Network configuration
 */
public class NetConfiguration {
//    protected static final String USER_AGENT = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36";
//    protected final String theBaseUrl = "http://10.5.7.17:8090/api/";
//    protected final String theBaseUrl = "http://10.5.7.19:8090/api/";
//    protected final String theBaseUrl = "http://10.5.7.14:8080/api/";
    protected final String theBaseUrl = "http://10.5.7.23:8080/api/";
//      protected final String theBaseUrl = "http://192.168.1.244:8080/api/";
//     protected final String theBaseUrl = "http://10.0.22.35:8080/api/";


//    protected static   String theToken = "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJBZG1pbiwkMmEkMTAkNWpkbS9CZ1hwbTZxbUt3MC5OMFVqdWtaMExSZkpaelphSXk0ZlI5aVYxN2xtTFVtZndaQ3EiLCJpc3MiOiJBRFREQU0iLCJpYXQiOjE2NjgxNjgyODksImV4cCI6MTY2ODI1NDY4OX0.4fjz0kg7MrEO91Y9zWVyt6zpj4b4hTZnYiFm0_sYVX9O8W1eHzVAuGCri-W4x13gThtF0yf_wdVCptEt683QcQ";
//    protected static   String theToken = "";


}
