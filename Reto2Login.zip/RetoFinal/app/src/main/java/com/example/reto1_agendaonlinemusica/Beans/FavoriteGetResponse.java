package com.example.reto1_agendaonlinemusica.Beans;

import java.io.Serializable;

public class FavoriteGetResponse implements Serializable {

    private String username;
    private int idSong;

    public FavoriteGetResponse() {
        super();
    }

    public FavoriteGetResponse(String username, int idSong) {
        super();
        this.username = username;
        this.idSong = idSong;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getIdSong() {
        return idSong;
    }

    public void setIdSong(int idSong) {
        this.idSong = idSong;
    }

    @Override
    public String toString() {
        return "Favorite [username=" + username + ", idSong=" + idSong + "]";
    }
}
