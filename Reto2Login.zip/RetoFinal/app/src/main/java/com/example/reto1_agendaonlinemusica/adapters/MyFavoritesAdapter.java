package com.example.reto1_agendaonlinemusica.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.example.reto1_agendaonlinemusica.Beans.Song;
import com.example.reto1_agendaonlinemusica.R;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

/**
 * Simple adapter for the favorites
 */
public class MyFavoritesAdapter extends ArrayAdapter<Song> {

    private final ArrayList<Song> favorites;
    private final Context context;
    ImageView imageViewSongs = null;
    ImageView imageViewFavorites;

    public MyFavoritesAdapter(@NonNull Context context, int resource, @NotNull ArrayList<Song> favorites) {
        super(context, resource, favorites);
        this.context = context;
        this.favorites = favorites;
    }

    @Override
    public int getCount() {
        return super.getCount();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater layoutInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.favorite_layout, null);

        String Image = favorites.get(position).getImage();

        ((TextView) view.findViewById(R.id.titleTextView)).setText(favorites.get(position).getTitle());
        ((TextView) view.findViewById(R.id.authorTextView)).setText(favorites.get(position).getAuthor());
        imageViewSongs = (ImageView) view.findViewById(R.id.imageViewSong);
        Glide.with(context.getApplicationContext()).load(Image).into(imageViewSongs);
        imageViewFavorites = (ImageView) view.findViewById(R.id.imageViewFavorite);
        return view;
    }
}