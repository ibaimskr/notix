package com.example.reto1_agendaonlinemusica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.reto1_agendaonlinemusica.Beans.RegisterRequest;
import com.example.reto1_agendaonlinemusica.Network.RegisterService;


public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Button buttonRegister = findViewById(R.id.ButtonRegisterRegister);
        Button buttonCancel = findViewById(R.id.ButtonCancelRegister);

        EditText editTextUser = findViewById(R.id.EditTextUserRegister);
        EditText editTextName = findViewById(R.id.EditTextNameRegister);
        EditText editTextSurname = findViewById(R.id.EditTextSurnameRegister);
        EditText editTextMail = findViewById(R.id.EditTextMailRegister);
        EditText editTextPass = findViewById(R.id.EditTextPasswordRegister);
        EditText editTextPass2 = findViewById(R.id.EditTextPassword2Register);

        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RegisterRequest userRequest = new RegisterRequest();

                if (editTextUser.getText().toString().equals("") || editTextName.getText().toString().equals("")
                        || editTextSurname.getText().toString().equals("")
                        || editTextMail.getText().toString().equals("") || editTextPass.getText().toString().equals("")
                        || editTextPass2.getText().toString().equals("")) {
                    Toast.makeText(RegisterActivity.this, R.string.blankField, Toast.LENGTH_SHORT).show();
                } else if (editTextPass.length() >= 5) {
                    if (editTextPass.getText().toString().equals(editTextPass2.getText().toString())) {

                        userRequest.setUser(editTextUser.getText().toString());
                        userRequest.setName(editTextName.getText().toString());
                        userRequest.setSurname(editTextSurname.getText().toString());
                        userRequest.setEmail(editTextMail.getText().toString());
                        userRequest.setPasswd(editTextPass.getText().toString());

                        int resp = registrarUsuario(userRequest);
                        if (resp == 500) {
                            Toast.makeText(getApplicationContext(), R.string.userExists, Toast.LENGTH_SHORT).show();
                        } else {

                            Intent i = new Intent();
                            i.putExtra("username", userRequest.getUser());
                            i.putExtra("password", userRequest.getPasswd());
                            setResult(2, i);
                            finish();

                            Toast.makeText(getApplicationContext(), R.string.createdUser, Toast.LENGTH_SHORT).show();
                        }

                    } else {
                        Toast.makeText(getApplicationContext(), R.string.checkPass, Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), R.string.fiveCheckPass, Toast.LENGTH_SHORT).show();

                }
            }

            private int registrarUsuario(RegisterRequest user) {
                int registrado = 0;
                if (isConnected()) {
                    RegisterService createUser = new RegisterService(user);
                    Thread thread = new Thread(createUser);
                    try {
                        thread.start();
                        thread.join(); // Awaiting response from the server...
                    } catch (InterruptedException e) {
                        // Nothing to do here...
                    }
                    // Processing the answer
                    registrado = createUser.getResponse();
                }
                return registrado;
            }

            public boolean isConnected() {
                boolean ret = false;
                try {
                    ConnectivityManager connectivityManager = (ConnectivityManager) getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
                    NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
                    if ((networkInfo != null) && (networkInfo.isAvailable()) && (networkInfo.isConnected())) {
                        ret = true;
                    }
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), getString(R.string.error_communication), Toast.LENGTH_SHORT).show();
                }
                return ret;
            }
        });

        buttonCancel.setOnClickListener(view -> {
            Intent i = new Intent();
            setResult(1, i);
            finish();
        });

    }
}