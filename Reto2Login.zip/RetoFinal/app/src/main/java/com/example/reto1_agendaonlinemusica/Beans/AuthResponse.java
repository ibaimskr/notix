package com.example.reto1_agendaonlinemusica.Beans;

public class AuthResponse {

    private String user;
    private String accessToken;
    private int error;

    public AuthResponse(String user, String accessToken) {
        super();
        this.user = user;
        this.accessToken = accessToken;
    }

    public int getError() {
        return error;
    }

    public void setError(int error) {
        this.error = error;
    }

    public AuthResponse() {
        super();
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }
}
