package com.example.reto1_agendaonlinemusica;

import static android.content.Intent.ACTION_VIEW;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.example.reto1_agendaonlinemusica.Beans.Song;
import com.example.reto1_agendaonlinemusica.Network.DeleteFavorite;
import com.example.reto1_agendaonlinemusica.Network.GetFavorites;
import com.example.reto1_agendaonlinemusica.adapters.MyFavoritesAdapter;

import java.util.ArrayList;

public class FavouriteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourite);

        Bundle extras = getIntent().getExtras();
        String token = extras.getString("token");

        Button buttonComeBack = findViewById(R.id.ButtonComeBackFavourite);

        ArrayList<Song> favorites = new ArrayList<>();

        MyFavoritesAdapter myFavoritesAdapter = new MyFavoritesAdapter(this, R.layout.favorite_layout, favorites);
        ((ListView) findViewById(R.id.ListViewFavouritesFavourite)).setAdapter(myFavoritesAdapter);

        if (isConnected()) {
            GetFavorites favoriteService = new GetFavorites(token);
            Thread thread = new Thread(favoriteService);
            try {
                thread.start();
                thread.join();
            } catch (InterruptedException e) {
                // Nothing to do here...
            }
            // Processing the answer
            ArrayList<Song> listFavorites = favoriteService.getResponse();

            if (listFavorites != null) {

                favorites.addAll(listFavorites);
                ((ListView) findViewById(R.id.ListViewFavouritesFavourite)).setAdapter(myFavoritesAdapter);

            } else
                Toast.makeText(getApplicationContext(), getString(R.string.nullListViewFavorites), Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getApplicationContext(), getString(R.string.error_communication), Toast.LENGTH_SHORT).show();
        }

        ((ListView) findViewById(R.id.ListViewFavouritesFavourite)).setOnItemClickListener((adapterView, view, position, l) -> {

            Song clickedSong = favorites.get(position);
            String url = clickedSong.getUrl();
            int idSong = clickedSong.getId();

            PopupMenu popupMenu = new PopupMenu(FavouriteActivity.this, (findViewById(R.id.ListViewFavouritesFavourite)));
            popupMenu.getMenuInflater().inflate(R.menu.favorite_menu, popupMenu.getMenu());
            popupMenu.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == (R.id.play_favorite)) {
                    Intent i = new Intent(ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);

                } else {
                    DeleteFavorite(idSong, token);
                    Toast.makeText(FavouriteActivity.this, R.string.songDeletedFromFavourites, Toast.LENGTH_SHORT).show();
                    favorites.remove(clickedSong);
                    ((ListView) findViewById(R.id.ListViewFavouritesFavourite)).setAdapter(myFavoritesAdapter);
                }
                return true;
            });
            popupMenu.show();

        });

        buttonComeBack.setOnClickListener(view -> finish());
    }

    private int DeleteFavorite(int idSong, String token) {
        int respuesta = 0;
        if (isConnected()) {
            DeleteFavorite deleteFavorite = new DeleteFavorite(idSong, token);
            Thread thread = new Thread(deleteFavorite);
            try {
                thread.start();
                thread.join(); // Awaiting response from the server...
            } catch (InterruptedException e) {
                // Nothing to do here...
            }
            // Processing the answer
            respuesta = deleteFavorite.getResponse();
        }
        return respuesta;
    }

    public boolean isConnected() {
        boolean ret = false;
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) getApplicationContext()
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            if ((networkInfo != null) && (networkInfo.isAvailable()) && (networkInfo.isConnected()))
                ret = true;
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), getString(R.string.error_communication), Toast.LENGTH_SHORT).show();
        }
        return ret;
    }
}