package com.example.reto1_agendaonlinemusica.Beans;

public class RegisterRequest {

    private String user;
    private String name;
    private String surname;
    private String email;
    private String passwd;

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public String getSurname() { return surname; }

    public void setSurname(String surname) { this.surname = surname; }

    public String getEmail() { return email; }

    public void setEmail(String email) { this.email = email; }

    public String getPasswd() {
        return passwd;
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    @Override
    public String toString() {
        return "{" +
                '"'+"user"+'"' +":"+'"'+ user + '"' +
                ","+'"'+"name"+ '"' +":" +'"'+ name + '"'+
                ","+'"'+"surname"+ '"' +":" +'"'+ surname + '"'+
                ","+'"'+"mail"+ '"' +":" +'"'+ email + '"'+
                ","+'"'+"passwd"+ '"' +":" +'"'+ passwd + '"'+
                "}";
    }
}
