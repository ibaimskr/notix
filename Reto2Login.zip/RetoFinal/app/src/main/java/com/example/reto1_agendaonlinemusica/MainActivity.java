package com.example.reto1_agendaonlinemusica;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.reto1_agendaonlinemusica.Beans.AuthRequest;
import com.example.reto1_agendaonlinemusica.Beans.AuthResponse;
import com.example.reto1_agendaonlinemusica.Beans.UserRemember;
import com.example.reto1_agendaonlinemusica.DB.DataManager;
import com.example.reto1_agendaonlinemusica.Network.LoginService;

import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    EditText editTextUser;
    EditText editTextPass;
    DataManager dataManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button buttonRegister = findViewById(R.id.ButtonRegisterMain);
        Button buttonEnter = findViewById(R.id.ButtonEnterMain);
        Button buttonLanguage = findViewById(R.id.ButtonLanguageMain);
        CheckBox checkBoxRemember = findViewById(R.id.CheckBoxRememberMain);
        editTextUser = findViewById(R.id.EditTextUserMain);
        editTextPass = findViewById(R.id.EditTextPassMain);

        dataManager = new DataManager(this);
        UserRemember userRem = new UserRemember();
        AuthRequest userComp = new AuthRequest();

        if (!dataManager.isEmpty()) {
            List<UserRemember> users = dataManager.selectAllUsers();
            for (UserRemember userRemember : users) {
                editTextUser.setText(userRemember.getUser());
                editTextPass.setText(userRemember.getPass());
                checkBoxRemember.setChecked(true);
            }
        }

        buttonEnter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                userComp.setUser(editTextUser.getText().toString());
                userComp.setPasswd(editTextPass.getText().toString());
                userRem.setUser(userComp.getUser());
                userRem.setPass(userComp.getPasswd());

                int error;
                if (editTextUser.getText().toString().equals("") || editTextPass.getText().toString().equals("")) {
                    Toast.makeText(MainActivity.this, R.string.blankField, Toast.LENGTH_SHORT).show();
                } else {
                    try {
                        AuthResponse resp = checkLogin(userComp);
                        error = resp.getError();
                        String token = resp.getAccessToken();
                        String user = resp.getUser();
                        if (error == 401) {
                            Toast.makeText(getApplicationContext(), R.string.userOrPassFail, Toast.LENGTH_SHORT).show();
                            editTextUser.setText("");
                            editTextPass.setText("");

                        } else if (error == 400) {
                            Toast.makeText(getApplicationContext(), R.string.fiveCheckPass, Toast.LENGTH_SHORT).show();
                            editTextPass.setText("");

                        } else {
                            rememberMe();
                            Intent i = new Intent(MainActivity.this, ComunityActivity.class);
                            i.putExtra("token", token);
                            i.putExtra("user", user);
                            startActivityForResult(i, 1);
                        }

                    } catch (NullPointerException e) {
                        Toast.makeText(getApplicationContext(), R.string.error, Toast.LENGTH_SHORT).show();
                        editTextUser.setText("");
                        editTextPass.setText("");
                    }
                }
            }

            private void rememberMe() {
                UserRemember userdb = dataManager.selectUser();

                if (checkBoxRemember.isChecked()) {
                    if (dataManager.isEmpty()) {
                        dataManager.insert(userRem);
                    } else {
                        dataManager.delete(userdb.getUser());
                    }
                } else if (!dataManager.isEmpty()) {
                    dataManager.delete(userdb.getUser());
                }
            }

            private AuthResponse checkLogin(AuthRequest userComp) {
                AuthResponse usersResponse = new AuthResponse();
                if (isConnected()) {
                    LoginService getUser = new LoginService(userComp);
                    Thread thread = new Thread(getUser);
                    try {
                        thread.start();
                        thread.join(); // Awaiting response from the server...
                    } catch (InterruptedException e) {
                        // Nothing to do here...
                    }
                    // Processing the answer
                    usersResponse = getUser.getResponse(userComp);
                }
                return usersResponse;
            }

            public boolean isConnected() {
                boolean ret = false;
                try {
                    ConnectivityManager connectivityManager = (ConnectivityManager) getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
                    NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
                    if ((networkInfo != null) && (networkInfo.isAvailable()) && (networkInfo.isConnected())) {
                        ret = true;
                    }
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), getString(R.string.error_communication), Toast.LENGTH_SHORT).show();
                }
                return ret;
            }
        });

        buttonRegister.setOnClickListener(view -> {
            Intent i = new Intent(MainActivity.this, RegisterActivity.class);
            startActivityForResult(i, 2);
        });

        buttonLanguage.setOnClickListener(view -> {
            PopupMenu popupMenu = new PopupMenu(MainActivity.this, (findViewById(R.id.ButtonLanguageMain)));
            popupMenu.getMenuInflater().inflate(R.menu.language_menu, popupMenu.getMenu());

            popupMenu.setOnMenuItemClickListener(item -> {
                String language;
                if (item.getItemId() == (R.id.english)) {
                    language = "en";
                    setLang(language);
                    this.recreate();
                } else if (item.getItemId() == (R.id.spanish)) {
                    language = "es";
                    setLang(language);
                    this.recreate();
                } else {
                    language = "eu";
                    setLang(language);
                    this.recreate();
                }
                return true;
            });
            popupMenu.show();
        });


    }

    private void setLang(String lang) {

        Locale myLocale = new Locale(lang);
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        conf.locale = myLocale;
        res.updateConfiguration(conf, dm);


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 2) {
            String user = data.getStringExtra("username");
            String pass = data.getStringExtra("password");

            editTextUser.setText(user);
            editTextPass.setText(pass);

        }
        if (requestCode == 1) {
            if (!dataManager.isEmpty()) {
                List<UserRemember> users = dataManager.selectAllUsers();
                for (UserRemember userRemember : users) {
                    editTextUser.setText(userRemember.getUser());
                    editTextPass.setText(userRemember.getPass());
                }
            } else {

                editTextUser.setText("");
                editTextPass.setText("");
            }
        }
    }

}