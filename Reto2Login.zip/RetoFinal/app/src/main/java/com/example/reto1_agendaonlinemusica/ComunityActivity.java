package com.example.reto1_agendaonlinemusica;

import static android.content.Intent.ACTION_VIEW;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.example.reto1_agendaonlinemusica.Beans.Favorite;
import com.example.reto1_agendaonlinemusica.Beans.Song;
import com.example.reto1_agendaonlinemusica.Network.AddFavorite;
import com.example.reto1_agendaonlinemusica.Network.DeleteFavorite;
import com.example.reto1_agendaonlinemusica.Network.GetFavorites;
import com.example.reto1_agendaonlinemusica.Network.SongService;
import com.example.reto1_agendaonlinemusica.adapters.MySongsAdapter;

import java.util.ArrayList;

public class ComunityActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comunity);

        Bundle extras = getIntent().getExtras();
        String token = extras.getString("token");
        String user = extras.getString("user");


        Button buttonCloseSession = findViewById(R.id.ButtonCloseSessionComunity);
        Button buttonFavourites = findViewById(R.id.ButtonFavouritesComunity);
        ListView listViewSongs = findViewById(R.id.ListViewSongsComunity);


        ArrayList<Song> songsArrayList = new ArrayList<>();
        ArrayList<Song> favoritesArrayList = new ArrayList<>();

        MySongsAdapter mySongsAdapter = new MySongsAdapter(this, R.layout.song_layout, songsArrayList);
        listViewSongs.setAdapter(mySongsAdapter);

        if (isConnected()) {
            GetFavorites favoriteService = new GetFavorites(token);
            Thread thread = new Thread(favoriteService);
            try {
                thread.start();
                thread.join();
            } catch (InterruptedException e) {
                // Nothing to do here...
            }
            // Processing the answer
            ArrayList<Song> listFavorites = favoriteService.getResponse();

            if (listFavorites != null) {
                favoritesArrayList.addAll(listFavorites);
            }
        } else {
            Toast.makeText(getApplicationContext(), getString(R.string.error_communication), Toast.LENGTH_SHORT).show();
        }

        listViewSongs.setOnItemClickListener((adapterView, view, position, l) -> {
            Song clickedSong = songsArrayList.get(position);
            String url = clickedSong.getUrl();
            int idSong = clickedSong.getId();

            PopupMenu popupMenu = new PopupMenu(ComunityActivity.this, listViewSongs);
            popupMenu.getMenuInflater().inflate(R.menu.comunity_menu, popupMenu.getMenu());

            popupMenu.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == (R.id.play_comunity)) {

                    Intent i = new Intent(ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);

                } else if (item.getItemId() == (R.id.favourite_action)) {

                    Favorite favoriteRequest = new Favorite();
                    favoriteRequest.setUsername(user);
                    favoriteRequest.setIdSong(idSong);

                    int response = CreateFavorite(favoriteRequest, token);

                    if (response == 500) {

                        Toast.makeText(ComunityActivity.this, R.string.alreadyFavorite, Toast.LENGTH_SHORT).show();

                    } else {

                        Toast.makeText(ComunityActivity.this, R.string.songAddedToFavourites, Toast.LENGTH_SHORT).show();
                        favoritesArrayList.add(clickedSong);

                    }
                } else if (item.getItemId() == (R.id.unfavorite_action)) {
                    if (favoritesArrayList.size() == 0) {
                        Toast.makeText(ComunityActivity.this, R.string.yetFavorite, Toast.LENGTH_SHORT).show();
                    } else {
                        for (Song song : favoritesArrayList) {
                            if (song.getId() != clickedSong.getId()) {
                                Toast.makeText(ComunityActivity.this, R.string.yetFavorite, Toast.LENGTH_SHORT).show();
                            } else {
                                DeleteFavorite(idSong, token);
                                Toast.makeText(ComunityActivity.this, R.string.songDeletedFromFavourites, Toast.LENGTH_SHORT).show();
                                favoritesArrayList.remove(clickedSong);
                            }

                        }
                    }
                }

                return true;
            });

            popupMenu.show();

        });


        if (isConnected()) {
            SongService songService = new SongService(token);
            Thread thread = new Thread(songService);
            try {
                thread.start();
                thread.join(); // Awaiting response from the server...
            } catch (InterruptedException e) {
                // Nothing to do here...
            }
            // Processing the answer
            ArrayList<Song> listSongs = songService.getResponse();

            if (listSongs != null) {
                songsArrayList.addAll(listSongs);
                ((ListView) findViewById(R.id.ListViewSongsComunity)).setAdapter(mySongsAdapter);
            } else
                Toast.makeText(getApplicationContext(), getString(R.string.error_communication), Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getApplicationContext(), getString(R.string.error_communication), Toast.LENGTH_SHORT).show();

        }

        buttonCloseSession.setOnClickListener(view -> {
            Intent i = new Intent();
            setResult(1, i);
            finish();
        });

        buttonFavourites.setOnClickListener(view -> {

            Intent i = new Intent(ComunityActivity.this, FavouriteActivity.class);
            i.putExtra("token", token);
            startActivity(i);
        });
    }

    private int CreateFavorite(Favorite favoriteRequest, String token) {
        int respuesta = 0;
        if (isConnected()) {
            AddFavorite addFavorite = new AddFavorite(favoriteRequest, token);
            Thread thread = new Thread(addFavorite);
            try {
                thread.start();
                thread.join(); // Awaiting response from the server...
            } catch (InterruptedException e) {
                // Nothing to do here...
            }
            // Processing the answer
            respuesta = addFavorite.getResponse();
        }
        return respuesta;
    }

    private int DeleteFavorite(int idSong, String token) {
        int respuesta = 0;
        if (isConnected()) {
            DeleteFavorite deleteFavorite = new DeleteFavorite(idSong, token);
            Thread thread = new Thread(deleteFavorite);
            try {
                thread.start();
                thread.join(); // Awaiting response from the server...
            } catch (InterruptedException e) {
                // Nothing to do here...
            }
            // Processing the answer
            respuesta = deleteFavorite.getResponse();
        }
        return respuesta;
    }

    public boolean isConnected() {
        boolean ret = false;
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) getApplicationContext()
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            if ((networkInfo != null) && (networkInfo.isAvailable()) && (networkInfo.isConnected()))
                ret = true;
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), getString(R.string.error_communication), Toast.LENGTH_SHORT).show();
        }
        return ret;
    }

}