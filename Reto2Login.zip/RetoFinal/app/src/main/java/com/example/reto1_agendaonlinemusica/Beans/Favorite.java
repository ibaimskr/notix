package com.example.reto1_agendaonlinemusica.Beans;

import java.io.Serializable;

public class Favorite implements Serializable {

    private int idSong;
    private String username;

    public Favorite() {
    }

    public Favorite(int idSong, String username) {
        super();
        this.idSong = idSong;
        this.username = username;

    }

    public int getIdSong() {
        return idSong;
    }

    public void setIdSong(int idSong) {
        this.idSong = idSong;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String toString() {
        return "{" +
                '"'+"username"+'"' +":"+'"'+ username + '"' +
                ","+'"'+"idSong"+ '"' +":" +'"'+ idSong + '"'+
                "}";
    }
}
