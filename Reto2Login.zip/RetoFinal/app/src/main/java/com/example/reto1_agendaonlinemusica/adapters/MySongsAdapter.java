package com.example.reto1_agendaonlinemusica.adapters;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.example.reto1_agendaonlinemusica.Beans.Song;
import com.example.reto1_agendaonlinemusica.R;

import java.util.ArrayList;

/**
 * Simple adapter for the songs
 */
public class MySongsAdapter extends ArrayAdapter<Song> {

    private final ArrayList<Song> songs;

    private final Context context;
    ImageView imageViewSongs = null;

    public MySongsAdapter(@NonNull Context context, int resource, @NonNull ArrayList<Song> songs) {
        super(context, resource, songs);
        this.songs = songs;
        this.context = context;

    }

    @Override
    public int getCount() {
        return super.getCount();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater layoutInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.song_layout, null);

        String Image = songs.get(position).getImage();
        ((TextView) view.findViewById(R.id.titleTextView)).setText(songs.get(position).getTitle());
        ((TextView) view.findViewById(R.id.authorTextView)).setText(songs.get(position).getAuthor());
        imageViewSongs = (ImageView) view.findViewById(R.id.imageViewSong);
        Glide.with(context.getApplicationContext()).load(Image).into(imageViewSongs);
        return view;
    }


}
